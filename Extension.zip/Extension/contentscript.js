function blockKeywordOnPage(keyword) {
  const blockedKeyword = keyword.toLowerCase();
  const elements = document.getElementsByTagName('*');

  for (const element of elements) {
    for (const node of element.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        const text = node.textContent.toLowerCase();
        if (text.includes(blockedKeyword)) {
          const re = new RegExp(blockedKeyword, 'gi');
          node.textContent = node.textContent.replace(re, '🐾 Spoiler Blocked 🐾');
        }
      }
    }
  }
}

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === 'blockKeyword') {
    blockKeywordOnPage(message.blockedKeyword);
  }
});

// Listen for dynamic content changes and reapply the blocking logic
const observer = new MutationObserver(function(mutationsList) {
  for (const mutation of mutationsList) {
    if (mutation.type === 'childList') {
      chrome.storage.local.get('blockedKeyword', function(data) {
        const blockedKeyword = data.blockedKeyword;
        if (blockedKeyword) {
          blockKeywordOnPage(blockedKeyword);
        }
      });
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true });
