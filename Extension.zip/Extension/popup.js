document.addEventListener('DOMContentLoaded', function() {
  const blockButton = document.getElementById('blockButton');

  blockButton.addEventListener('click', function() {
    const keyword = document.getElementById('keyword').value.trim().toLowerCase();
    if (keyword) {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const activeTab = tabs[0];
        chrome.tabs.sendMessage(activeTab.id, { action: 'blockKeyword', blockedKeyword: keyword }, function() {
          alert(`Keyword "${keyword}" has been blocked.`);
        });
      });
    } else {
      alert('Please enter a valid keyword.');
    }
  });
});
