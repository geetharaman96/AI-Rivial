chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action === 'getBlockKeyword') {
    chrome.storage.local.get('blockedKeyword', function(data) {
      sendResponse({ blockedKeyword: data.blockedKeyword });
    });
    return true; // Need to return true to indicate that we want to send a response asynchronously
  }
});
